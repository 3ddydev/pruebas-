# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.



######################################################################

# __openerp__.py

{
    'name': 'Modulo de Compañia - CMP',
    'version': '1.1',
    'category': 'Accounting & Finance',
    'summary': 'Modulo de gestion compañia',
    'sequence': 30,
    'description': """
Es un módulo de compañia
======================
Con este modulo haremos una prueba  en Odoo.
 * 
 * 
 *
 *
 *
    """,
    'license' : 'AGPL-3',
    'depends': ['sale','base_setup', 'product', 'analytic', 'report'],
    'data': [
        'views/partner_view.xml',
        'views/hospital_view.xml',
        'views/especialidades_view.xml',
        'views/consultas_view.xml',
    ],
    'installable': True,
    'active': False,
    'auto_install': False,
}