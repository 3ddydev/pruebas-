# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# Copyright (C) 2018 EDISON GARCIA.

######################################################################

# __openerp__.py

{
    'name': 'Gestion de Compañias - CMPII',
    'version': '1.0',
    'author': 'Edison Garcia',
    'category': 'Accounting & Finance',
    'summary': 'Modulo de gestion de compañias 2018 ',
    'sequence': 30,
    
    'description': """
Es un módulo de prueba
======================
Con este modulo haremos nuestra primera prueba  en Odoo.
 * 
 * 
 *
 *
 *
 *
 *
 *
 *
 *
 *

    """,
    'license' : 'AGPL-3',
    'depends': ['sale','base_setup', 'product', 'analytic', 'report'],
    'data': [
        'views/partner_view.xml',
        'views/franchise_view.xml',
        'views/company_view.xml',
    ],
    'installable': True,
    'active': False,
    'auto_install': False,
}