# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from openerp.osv import fields, osv

class company(osv.osv):
	# declaramos el nombre empezando con un prefijo
	_name = 'sis.company'
	# Por donde se va a buscar
	_rec_name='nombre'
	_columns = {
	   'nombre' : fields.char('Compañia', size=80, required=True, help='Aqui pones el nombre'),
	   'partner_id': fields.many2one('res.partner', 'Clientes', ondelete='restrict'),
	}

company();
